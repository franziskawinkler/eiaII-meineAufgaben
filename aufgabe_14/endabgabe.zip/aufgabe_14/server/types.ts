/*Endabgabe
Name: <Franziska Winkler>
Matrikel: <260944>
Datum: <26.07.2019>
Hiermit versichere ich, dass ich diesen Code selbst geschrieben habe. Er wurde nicht kopiert und auch nicht diktiert.
*/
interface AssocStringString {
    [key: string]: string;
}
interface EISDEALER {
type: string;
name: string;
preis: number;
id: string;
value: number;
}
interface RemoveObject {
    id: string;
    type: string;
}

